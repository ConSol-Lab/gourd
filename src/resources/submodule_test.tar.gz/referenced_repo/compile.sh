#!/bin/sh

# advanced compiler optimizations
# (we are just copying a file)
cp run.sh compiled_program.sh
